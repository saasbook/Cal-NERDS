# Cal-NERDS

[![Maintainability](https://api.codeclimate.com/v1/badges/cc2cc04e461db816fbe3/maintainability)](https://codeclimate.com/github/cs169-group7/Cal-NERDS/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/cc2cc04e461db816fbe3/test_coverage)](https://codeclimate.com/github/cs169-group7/Cal-NERDS/test_coverage)
[![Build Status](https://travis-ci.org/cs169-group7/Cal-NERDS.svg?branch=master)](https://travis-ci.org/cs169-group7/Cal-NERDS)

[https://damp-brushlands-79654.herokuapp.com/](https://damp-brushlands-79654.herokuapp.com/)
